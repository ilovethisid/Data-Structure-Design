public class Graph {
	int rows;
	int columns=rows;
	int speed[][]=new int [rows][columns];
	
	Graph() {
		
	}
}