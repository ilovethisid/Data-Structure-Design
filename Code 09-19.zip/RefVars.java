
 public class RefVars {
	int count;
	int numOfVertices;
	int startVerIndex;
	int endVerIndex;
}